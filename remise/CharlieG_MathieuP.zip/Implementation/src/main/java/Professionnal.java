import java.util.ArrayList;

/**
 * Represents a Real Life profesionnal
 */
public class Professionnal extends Entity {

    public Professionnal(String name, String address,String province, String city, String postalCode, String comment, String email) {
        super(name, address, province, city, postalCode,  comment, email);
    }
}
